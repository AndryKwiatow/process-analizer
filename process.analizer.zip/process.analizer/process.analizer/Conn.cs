﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace process.analizer
{
    
    class Conn
    {
        public static SqlConnection GetDBConnection(string datasource, string database, string user, string password) {
            string connString = @"Data Source=" + datasource + ";Initial Catalog=" + database + ";Persist Security Info=true;User ID=" + user + ";Password=" + password;
            SqlConnection conn = new SqlConnection(connString);

            //Get connection info
            return conn;
        }
    }
}
