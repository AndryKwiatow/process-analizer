﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace process.analizer
{
    class DBInfo
    {
        public static SqlConnection conn_info = new SqlConnection();
        public static SqlConnection getDBConnection() {
            string datasource = @"LAPTOP-LT2GOAFM\SQLEXPRESS";
            string catalog = "U_ACCESS";
            string user = "sa";
            string password = "Pa$$w0rd" ;
            conn_info = Conn.GetDBConnection(datasource, catalog, user, password);

            return conn_info;
        }

        public string searchInfo(SqlConnection conn,string query) {
            try
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                conn.Open(); 
                SqlDataReader data = cmd.ExecuteReader();
                if (data.HasRows)
                {
                    data.Read();
                    return data.GetString(1).ToString();
                }
                else
                {
                    return "No match found";
                }
                
            }
            catch (SqlException ex)
            {
                return ex.Message.ToString();
            }
        }

    }
}
