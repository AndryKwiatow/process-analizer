﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace process.analizer
{
    class DBInfo
    {

        public string searchInfo(SqlConnection conn,string query) {
            DataTable dt = new DataTable();
            try
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                conn.Open(); 
                SqlDataReader data = cmd.ExecuteReader();
                if (data.HasRows)
                {
                        
                    data.Read();
                    return data.GetString(0).ToString();
                }
                else
                {
                    return "No match found";
                }
                
            }
            catch (SqlException ex)
            {
                return ex.Message.ToString();
            }
        }

    }
}
