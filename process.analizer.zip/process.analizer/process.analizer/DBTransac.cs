﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Data.Sql;

namespace process.analizer
{
    class DBTransac
    {
        SqlConnection lDBConnection = GetDBConnection(@"ARAMOS\SQLEXPRESS", "app_info", "sa", "Pa$$w0rd"); 
        public static SqlConnection GetDBConnection(string datasource, string database, string user, string password)
        {
            string connString = @"Data Source=" + datasource + ";Initial Catalog=" + database + ";Persist Security Info=true;User ID=" + user + ";Password=" + password;
            SqlConnection conn = new SqlConnection(connString);
            
            //Get connection info
            return conn;
        }
        public DataSet searchInfo(string query, ref string mensaje) {
            try
            {
                SqlCommand cmd = new SqlCommand(query, lDBConnection);
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = cmd;
                DataSet ds = new DataSet();
                lDBConnection.Open();
                da.Fill(ds);
                lDBConnection.Close();

                return ds;
            }
            catch (Exception ex)
            {
                mensaje = ex.Message;
                return null;
            }
        }

    }
}
