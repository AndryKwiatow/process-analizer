﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace process.analizer
{
    public partial class pnMain : Form
    {
        private Form WFMain = new WFMain();
        private DBInfo db_query = new DBInfo();
        public pnMain()
        {
            InitializeComponent();
        }

        private void lblUsername_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            //WFMain.Show();
            //this.Visible = false;
            System.Console.Write(db_query.searchInfo(DBInfo.conn_info, "SELECT username, pwd FROM user_info WHERE userN='" + txtUsername.Text + "' AND pwd= ENCRYPTBYPASSPHRASE('" + txtPwd.Text + "', '" + txtUsername.Text + "')"));
        }

        private void pbLoad_Click(object sender, EventArgs e)
        {

        }
    }
}
