﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace process.analizer
{
    class Access
    {
        public static Int32 GetSeed(string seedString)
        {
            Int32 seed = 0;
            for (int i = 0; i < seedString.Length; i++) {
                seed ^= seedString[i];
            }
            return seed;
        }
        public static byte[] KeyGen (string text, int Key_Length)
        {
            Int32 seed = GetSeed(text);
            Random num = new Random(seed);
            byte[] key = new byte[Key_Length];
            for(int i = 0; i < Key_Length; i++)
            {
                key[i] = (byte)num.Next(256);
            }
            return key;
        }
        public static byte[] Encrypt (String text, string key)
        { 
            Aes Encryptor = Aes.Create();
            byte[] Data = System.Text.Encoding.UTF8.GetBytes(text); 
            Encryptor.Key = KeyGen(key, 16);
            Encryptor.IV = KeyGen(key + "pwd", 16);
            Data = Encryptor.CreateEncryptor().TransformFinalBlock(Data, 0, Data.Length);
            return Data;
        }
        /*public static String Decrypt(string text, String key)
        {
            Aes Decryptor = Aes.Create();
            byte[] Data = Encrypt(text, key);
            Decryptor.Key = KeyGen(key, 16);
            Decryptor.IV = KeyGen(key + "pwd", 16);
            Data = Decryptor.CreateDecryptor().TransformFinalBlock(Data, 0, Data.Length);
            return Convert.to(Data);
        }*/
    }

}
