﻿namespace process.analizer
{
    partial class WFCreateActivity
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CBActivity = new System.Windows.Forms.ComboBox();
            this.lblActivity = new System.Windows.Forms.Label();
            this.btnSearchClient = new System.Windows.Forms.Button();
            this.txtClient = new System.Windows.Forms.TextBox();
            this.btnStart = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // CBActivity
            // 
            this.CBActivity.DropDownHeight = 140;
            this.CBActivity.FormattingEnabled = true;
            this.CBActivity.IntegralHeight = false;
            this.CBActivity.ItemHeight = 13;
            this.CBActivity.Location = new System.Drawing.Point(55, 63);
            this.CBActivity.Name = "CBActivity";
            this.CBActivity.Size = new System.Drawing.Size(159, 21);
            this.CBActivity.TabIndex = 0;
            this.CBActivity.SelectedIndexChanged += new System.EventHandler(this.CBActivity_SelectedIndexChanged);
            // 
            // lblActivity
            // 
            this.lblActivity.AutoSize = true;
            this.lblActivity.Location = new System.Drawing.Point(231, 66);
            this.lblActivity.Name = "lblActivity";
            this.lblActivity.Size = new System.Drawing.Size(83, 13);
            this.lblActivity.TabIndex = 1;
            this.lblActivity.Text = "Register Activity";
            // 
            // btnSearchClient
            // 
            this.btnSearchClient.Location = new System.Drawing.Point(542, 63);
            this.btnSearchClient.Name = "btnSearchClient";
            this.btnSearchClient.Size = new System.Drawing.Size(178, 21);
            this.btnSearchClient.TabIndex = 3;
            this.btnSearchClient.Text = "Buscar Cliente / Proyecto";
            this.btnSearchClient.UseVisualStyleBackColor = true;
            this.btnSearchClient.Click += new System.EventHandler(this.btnSearchClient_Click);
            // 
            // txtClient
            // 
            this.txtClient.Location = new System.Drawing.Point(436, 64);
            this.txtClient.Name = "txtClient";
            this.txtClient.Size = new System.Drawing.Size(100, 20);
            this.txtClient.TabIndex = 4;
            this.txtClient.Text = "Hello";
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(322, 189);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(75, 23);
            this.btnStart.TabIndex = 5;
            this.btnStart.Text = "Start ";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // WFCreateActivity
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.txtClient);
            this.Controls.Add(this.btnSearchClient);
            this.Controls.Add(this.lblActivity);
            this.Controls.Add(this.CBActivity);
            this.Name = "WFCreateActivity";
            this.Text = "WFCreateActivity";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox CBActivity;
        private System.Windows.Forms.Label lblActivity;
        private System.Windows.Forms.Button btnSearchClient;
        public System.Windows.Forms.TextBox txtClient;
        private System.Windows.Forms.Button btnStart;
    }
}