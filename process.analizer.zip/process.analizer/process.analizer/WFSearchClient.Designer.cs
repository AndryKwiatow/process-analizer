﻿namespace process.analizer
{
    partial class WFSearchClient
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tblClient = new System.Windows.Forms.DataGridView();
            this.btnConfirmClient = new System.Windows.Forms.Button();
            this.lColumnNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lcolumnDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.tblClient)).BeginInit();
            this.SuspendLayout();
            // 
            // tblClient
            // 
            this.tblClient.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tblClient.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.lColumnNumber,
            this.lcolumnDescription});
            this.tblClient.Location = new System.Drawing.Point(-5, 63);
            this.tblClient.Name = "tblClient";
            this.tblClient.Size = new System.Drawing.Size(506, 126);
            this.tblClient.TabIndex = 0;
            // 
            // btnConfirmClient
            // 
            this.btnConfirmClient.Location = new System.Drawing.Point(411, 195);
            this.btnConfirmClient.Name = "btnConfirmClient";
            this.btnConfirmClient.Size = new System.Drawing.Size(75, 23);
            this.btnConfirmClient.TabIndex = 1;
            this.btnConfirmClient.Text = "OK";
            this.btnConfirmClient.UseVisualStyleBackColor = true;
            this.btnConfirmClient.Click += new System.EventHandler(this.btnConfirmClient_Click);
            // 
            // lColumnNumber
            // 
            this.lColumnNumber.HeaderText = "Project Number";
            this.lColumnNumber.Name = "lColumnNumber";
            this.lColumnNumber.Width = 112;
            // 
            // lcolumnDescription
            // 
            this.lcolumnDescription.HeaderText = "Project Name ";
            this.lcolumnDescription.Name = "lcolumnDescription";
            this.lcolumnDescription.Width = 250;
            // 
            // WFSearchClient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(498, 224);
            this.Controls.Add(this.btnConfirmClient);
            this.Controls.Add(this.tblClient);
            this.Name = "WFSearchClient";
            this.Text = "WFSearchClient";
            ((System.ComponentModel.ISupportInitialize)(this.tblClient)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView tblClient;
        private System.Windows.Forms.Button btnConfirmClient;
        private System.Windows.Forms.DataGridViewTextBoxColumn lColumnNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn lcolumnDescription;
    }
}