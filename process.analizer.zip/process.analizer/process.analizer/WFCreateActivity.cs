﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace process.analizer
{
    public partial class WFCreateActivity : Form
    {
        static DBTransac ldsDB = new DBTransac();
        static WFSearchClient wfSearchClient = new WFSearchClient();
        private WFActivityInfo wfActivityInfo; 

        string lsMessage = "";
        string lsClient = string.Empty;
        string lsQuery = string.Empty;
        string [,] lsActivity = null;


        public WFCreateActivity()
        {
            InitializeComponent();
            lsQuery = "SELECT * FROM activities";
            lsActivity = getActivity(lsQuery, ref lsMessage);
            string[] lsActivitySource = new string[lsActivity.Length / 2];
            MessageBox.Show("Array's length: " + lsActivitySource.Length);
            try
            {
                for (int i = 0; i < lsActivitySource.Length; i++)
                {
                    lsActivitySource[i] = lsActivity[i, 0];
                    //lsActivitySource = lsActivity[i , 0];
                }
                CBActivity.DataSource = lsActivitySource;
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            //CBActivity.DataSource = getActivity(lsQuery, ref lsMessage);
        }
        public static string[,] getActivity(string query, ref string message)
        {
            DataSet ldsActivity = ldsDB.searchInfo(query, ref message);
            string[,] lsActivity = null;
            int liCountActivity = 0;
            if (message.Equals(""))
            {
                if ((ldsActivity.Tables.Count > 0) && (ldsActivity.Tables[0].Rows.Count > 0))
                {
                    liCountActivity = ldsActivity.Tables[0].Rows.Count;
                    lsActivity = new string[liCountActivity, liCountActivity];
                    for (int i = 0; i < liCountActivity; i++)
                    {
                        for (int j = 0; j < 2; j++)
                        {
                            if (j == 0)

                            {
                                lsActivity[i, j] = ldsActivity.Tables[0].Rows[i]["description"].ToString();
                            }
                            else if (j == 1)
                            {
                                lsActivity[i, j] = ldsActivity.Tables[0].Rows[i]["activity_id"].ToString();
                            }
                        }
                    }
                }
                else
                {
                    MessageBox.Show("There are no activities");
                }
            }
            else
            {
                MessageBox.Show("There was an error :" + message);
            }
            return lsActivity;
        }
        private void CBActivity_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnSearchClient_Click(object sender, EventArgs e)
        {
            wfSearchClient.Visible = true; 
            wfSearchClient.Show();
            this.Visible = false;
        }
        public void updateLabel()
        {
            try
            {
                txtClient.Text = lsClient;
            }
            catch (Exception e)
            {
                MessageBox.Show("Error: " + e.Message);
                Refresh();
            }
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            string lsProject = lsClient;

            wfActivityInfo = new WFActivityInfo();
            wfActivityInfo.Visible = true;
            wfActivityInfo.startTimer();
        }
    }
}
