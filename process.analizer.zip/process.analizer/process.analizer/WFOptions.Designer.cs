﻿namespace process.analizer
{
    partial class WFOptions
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(WFOptions));
            this.btnRegister = new System.Windows.Forms.Button();
            this.btnCreateActivity = new System.Windows.Forms.Button();
            this.btnProject = new System.Windows.Forms.Button();
            this.btnUser = new System.Windows.Forms.Button();
            this.btnSeeAll = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnRegister
            // 
            resources.ApplyResources(this.btnRegister, "btnRegister");
            this.btnRegister.Name = "btnRegister";
            this.btnRegister.UseVisualStyleBackColor = true;
            this.btnRegister.Click += new System.EventHandler(this.btnRegister_Click);
            // 
            // btnCreateActivity
            // 
            resources.ApplyResources(this.btnCreateActivity, "btnCreateActivity");
            this.btnCreateActivity.Name = "btnCreateActivity";
            this.btnCreateActivity.UseVisualStyleBackColor = true;
            this.btnCreateActivity.Click += new System.EventHandler(this.btnCreateActivity_Click);
            // 
            // btnProject
            // 
            resources.ApplyResources(this.btnProject, "btnProject");
            this.btnProject.Name = "btnProject";
            this.btnProject.UseVisualStyleBackColor = true;
            this.btnProject.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnUser
            // 
            resources.ApplyResources(this.btnUser, "btnUser");
            this.btnUser.Name = "btnUser";
            this.btnUser.UseVisualStyleBackColor = true;
            // 
            // btnSeeAll
            // 
            resources.ApplyResources(this.btnSeeAll, "btnSeeAll");
            this.btnSeeAll.Name = "btnSeeAll";
            this.btnSeeAll.UseVisualStyleBackColor = true;
            this.btnSeeAll.Click += new System.EventHandler(this.button4_Click);
            // 
            // WFOptions
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.btnSeeAll);
            this.Controls.Add(this.btnUser);
            this.Controls.Add(this.btnProject);
            this.Controls.Add(this.btnCreateActivity);
            this.Controls.Add(this.btnRegister);
            this.Name = "WFOptions";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnRegister;
        private System.Windows.Forms.Button btnCreateActivity;
        private System.Windows.Forms.Button btnProject;
        private System.Windows.Forms.Button btnUser;
        private System.Windows.Forms.Button btnSeeAll;
    }
}