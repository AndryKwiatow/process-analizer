﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace process.analizer
{
    public partial class WFSearchClient : Form
    {
        static DBTransac execSQL = new DBTransac();
        static WFCreateActivity wfCreateActivity = new WFCreateActivity();
        static string _sProject = string.Empty;
        private static string lsQuery = "SELECT * FROM client";
        public string lsMessage = "";
        private string[,] lsProjectList;
        static int liCount = 0;
        

        public WFSearchClient()
        {
            InitializeComponent();
            

            this.Visible = false;
            lsProjectList = getClient(lsQuery, ref lsMessage);
            try
            {
                for (int i = 0; i < liCount; i++)
                {
                    for (int j = 0; j < 2; j++)
                    {
                        tblClient.Rows[i].Cells[j].Value = lsProjectList[i, j];
                        //_sProject = _sProject + lsProjectList[i, j];
                    }
                    
                }
            }
            catch (Exception e)
            {
                MessageBox.Show("Error getting list of clients: " + e.Message);
            }
            
        }

        public static string[,] getClient(string query, ref string message)
        {
            DataSet ldsProject = execSQL.searchInfo(query, ref message);
            string [,] lsProjectNumber = null;
            int liProject = 0;
            if (message.Equals(""))
            {
                try
                {
                    if ((ldsProject.Tables.Count > 0) && (ldsProject.Tables[0].Rows.Count > 0))
                    {
                        liProject = ldsProject.Tables[0].Rows.Count;
                        liCount = liProject;
                        lsProjectNumber = new string[liProject, 2];
                        for (int i = 0; i < liProject; i++)
                        {
                            for (int j = 0; j < 2; j++)
                            {
                                if (j == 0)
                                {
                                    lsProjectNumber[i, j] = ldsProject.Tables[0].Rows[i]["project_number"].ToString();
                                }
                                else if (j == 1)
                                {
                                    lsProjectNumber[i, j] = ldsProject.Tables[0].Rows[i]["name"].ToString();
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("There was an error getting client's info: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("There was an error: " + message);
            }

            return lsProjectNumber;
        }

        private void btnConfirmClient_Click(object sender, EventArgs e)
        {
            if (tblClient.SelectedRows.Count > 0)
            {
                this.Visible = false;
                int liCountCell = tblClient.SelectedCells.Count; 
                //_sProject = tblClient.SelectedCells.ToString();
                //_sProject = tblClient.SelectedRows[0].ToString();
                if (tblClient.SelectedCells.Count > 0)
                {
                    for (int i = 0; i < tblClient.SelectedCells.Count; i++)
                    {
                        _sProject = _sProject + tblClient.SelectedCells[i].Value.ToString();
                    }
                }
                wfCreateActivity.txtClient.Text = _sProject;
                //wfCreateActivity.updateLabel();
                wfCreateActivity.Refresh();
                wfCreateActivity.Visible = true; 
            }
        }
    }
}
