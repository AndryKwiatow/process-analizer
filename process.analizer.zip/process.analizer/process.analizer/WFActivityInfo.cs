﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace process.analizer
{
    public partial class WFActivityInfo : Form
    {
        Stopwatch stopwatch = new Stopwatch();

        public WFActivityInfo()
        {
            InitializeComponent();
        }
        
        //TimeSpan ts = new TimeSpan();

        public void txtTimer_Click(object sender, EventArgs e)
        {
            stopwatch.Start();
            Timer timer = new Timer();
            timer.Interval = 1;
            timer.Tick += timer_Tick;
            timer.Start();
        }
        private void timer_Tick(object sender, EventArgs e)
        {
            textBox1.Text = stopwatch.Elapsed.ToString("hh\\:mm\\:ss");
            //textBox1.Text = stopwatch.ElapsedMilliseconds.ToString("hh\\:mm\\:ss.fff");
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }
        private void btnStop_Click(object sender, EventArgs e)
        {
            stopwatch.Stop();
        }
        public void startTimer()
        {
            stopwatch.Start();
            Timer timer = new Timer();
            timer.Interval = 1;
            timer.Tick += timer_Tick;
            timer.Start();
        }
    }
}
