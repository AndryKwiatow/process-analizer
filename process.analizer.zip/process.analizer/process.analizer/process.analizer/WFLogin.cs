﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace process.analizer
{
    public partial class pnMain : Form
    {
        private Form WFMain = new WFMain();
        private DBInfo db_query = new DBInfo();
        public pnMain()
        {
            InitializeComponent();
        }

        private void lblUsername_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            //System.Console.Write(db_query.searchInfo(Conn.GetDBConnection(@"LAPTOP-LT2GOAFM\SQLEXPRESS", "app_info","sa","Pa$$w0rd"), "SELECT name, pwd FROM [dbo].[user] WHERE name='" + txtUsername.Text + "' AND pwd= ENCRYPTBYPASSPHRASE('" + txtPwd.Text + "', '" + txtUsername.Text + txtPwd.Text+ "')"));
            //txtUsername.Text = Convert.ToBase64String(Access.Encrypt(txtPwd.Text, txtUsername.Text));
            //txtUsername.Text = Access.Decrypt(db_query.searchInfo(Conn.GetDBConnection(@"LAPTOP-LT2GOAFM\SQLEXPRESS", "app_info", "sa", "Pa$$w0rd"), "SELECT pwd FROM [dbo].[user] WHERE user_id = '" + txtUsername.Text + "'"), txtUsername.Text);

            //Querys database to get pwd info in databae
            //string dbEncr = db_query.searchInfo(Conn.GetDBConnection(@"LAPTOP-LT2GOAFM\SQLEXPRESS", "app_info", "sa", "Pa$$w0rd"), "SELECT pwd FROM [dbo].[user] WHERE user_id = '" + txtUsername.Text + "'");
            string lsQuery = "SELECT * FROM [dbo].[user]";
            string lsMensaje = "";
            string lsPass = "";
            DataSet ldsUser = db_query.searchInfo(Conn.GetDBConnection(@"LAPTOP-LT2GOAFM\SQLEXPRESS", "app_info", "sa", "Pa$$w0rd"), lsQuery, ref lsMensaje);
            if (lsMensaje.Equals(""))
            {
                if ((ldsUser.Tables.Count > 0) && (ldsUser.Tables[0].Rows.Count > 0))
                {
                    lsPass = ldsUser.Tables[0].Rows[0]["pwd"].ToString();
                }
                else
                {
                    MessageBox.Show("No se encontraron registros");
                }
                //Converts and encrypts current pwd in application
                string txtPass = Convert.ToBase64String(Access.Encrypt(txtPwd.Text, txtUsername.Text));
                //if(true)
                if (txtPass == lsPass)
                {
                    txtUsername.Text = "Welcome";
                    WFMain.Show();
                    this.Visible = false;
                }
                else
                {
                    MessageBox.Show("Usuario o contraseña incorrecta");
                }
            }
            else
            {
                MessageBox.Show("Error en la conexión a DB: " + lsMensaje);
            }
        }

        private void pbLoad_Click(object sender, EventArgs e)
        {

        }
    }
}
